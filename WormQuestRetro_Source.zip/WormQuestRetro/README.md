# Worm Quest Retro (Android)

A playable early-2000s-inspired Snake variant, built in native Java with Android Canvas. The gameplay grid is **18 × 24 cells (3:4)** and scales to the screen without stretching.

## Gameplay
- D-pad or swipe to steer in four cardinal directions.
- Collect 25 apples to complete each of 5 levels. Each apple spawns at a random unoccupied grid location.
- Worm starts at 20 cells. Each apple adds **one cell**, exactly **5% of its original length**.
- Hitting the outside boundary resets the entire game to level 1.
- Crossing your own body removes the body from the crossing point through the old tail; play continues.
- Levels 2 and 3 introduce static obstacles; levels 4 and 5 add moving hazards. Hitting an obstacle restarts the current level.
- Level unlocks persist via Android SharedPreferences.
- Touch START / PAUSE or tap the board to toggle pause; swipe on the board or use on-screen arrow controls.

## Build APK
1. Install Android Studio (with Android SDK 35 and JDK 17).
2. Open the `WormQuestRetro` folder as a project.
3. Allow Android Studio to sync Gradle (Android Gradle Plugin 8.6.1).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

No network permissions, ads, or third-party game dependencies. This source project is supplied because the Android SDK/Gradle build environment is not available in the current execution environment; the APK has not been compiled or device-tested here.
