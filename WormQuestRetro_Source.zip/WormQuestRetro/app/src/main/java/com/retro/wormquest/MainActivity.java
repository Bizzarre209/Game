package com.retro.wormquest;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int COLS = 18, ROWS = 24, GOAL = 25;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final LinkedList<Cell> worm = new LinkedList<>(); // head at index 0
    private final Set<Cell> walls = new HashSet<>();
    private final List<Cell> hazards = new ArrayList<>();
    private final List<Integer> hazardDirs = new ArrayList<>();
    private final int[] dx = {0,1,0,-1}, dy = {-1,0,1,0};
    private int direction = 1, nextDirection = 1, level = 1, apples = 0, targetLength = 20;
    private int unlocked = 1, tickCount = 0;
    private Cell apple;
    private boolean paused = true, transitioning = false, victory = false;
    private GameView gameView;
    private TextView hud, status;
    private SharedPreferences prefs;

    static final class Cell {
        final int x,y;
        Cell(int x,int y){this.x=x;this.y=y;}
        @Override public boolean equals(Object o){if(!(o instanceof Cell))return false; Cell c=(Cell)o;return x==c.x&&y==c.y;}
        @Override public int hashCode(){return 31*x+y;}
    }

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(17,25,26));
        getWindow().setNavigationBarColor(Color.rgb(17,25,26));
        prefs=getSharedPreferences("wormquest",MODE_PRIVATE);
        unlocked=prefs.getInt("unlocked",1);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(10),dp(12),dp(10),dp(8));
        root.setBackgroundColor(Color.rgb(17,25,26));
        TextView title=label("WORM QUEST  '03",23,Color.rgb(238,223,139));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(44)));
        hud=label("",16,Color.rgb(190,232,176));
        root.addView(hud,new LinearLayout.LayoutParams(-1,dp(31)));
        FrameLayout boardFrame=new FrameLayout(this);
        gameView=new GameView(this);
        boardFrame.addView(gameView,new FrameLayout.LayoutParams(-1,-1));
        status=label("TAP START",20,Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(0x880B181A);
        boardFrame.addView(status,new FrameLayout.LayoutParams(-1,-1));
        root.addView(boardFrame,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);
        TextView up=button("▲",0);bottom.addView(up,new LinearLayout.LayoutParams(-1,dp(55)));
        LinearLayout sides=new LinearLayout(this);sides.setOrientation(LinearLayout.HORIZONTAL);
        for(int d:new int[]{3,2,1}){
            TextView b=button(d==3?"◀":d==2?"▼":"▶",d);
            sides.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));
        }
        bottom.addView(sides);
        LinearLayout menu=new LinearLayout(this);
        TextView start=label("START / PAUSE",15,Color.WHITE);start.setBackgroundColor(0xFF35645B);
        start.setOnClickListener(v->toggle());
        menu.addView(start,new LinearLayout.LayoutParams(0,dp(46),1));
        TextView restart=label("RESTART",15,Color.WHITE);restart.setBackgroundColor(0xFF765039);
        restart.setOnClickListener(v->{newGame(1);status.setText("PAUSED\n\nPRESS START");paused=false;refresh();});
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(46),1);rp.leftMargin=dp(7);menu.addView(restart,rp);
        bottom.addView(menu);
        root.addView(bottom,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        newGame(1);
        handler.postDelayed(loop,150);
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int size,int color){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER);t.setTypeface(android.graphics.Typeface.MONOSPACE,1);return t;
    }
    private TextView button(String symbol,int dir){
        TextView b=label(symbol,29,Color.rgb(234,239,199));b.setBackgroundColor(0xFF294A43);
        b.setOnClickListener(v->setDirection(dir));return b;
    }
    private void setDirection(int d){
        if((d+2)%4!=direction)nextDirection=d;
        if(paused&&!transitioning&&!victory){paused=false;refresh();}
    }
    private void toggle(){
        if(victory){newGame(1);paused=false;}
        else if(transitioning){level++;newGame(level);paused=false;}
        else paused=!paused;
        refresh();
    }
    private void newGame(int newLevel){
        level=newLevel;apples=0;tickCount=0;targetLength=20;direction=1;nextDirection=1;
        if(status!=null)status.setText("PAUSED\n\nPRESS START");
        paused=true;transitioning=false;victory=false;
        worm.clear();walls.clear();hazards.clear();hazardDirs.clear();
        // 20-cell starting body: a compact winding shape, safely away from boundaries.
        int[][] initial={{8,12},{7,12},{6,12},{5,12},{4,12},{3,12},{3,13},{4,13},{5,13},{6,13},
                         {7,13},{8,13},{9,13},{10,13},{11,13},{12,13},{12,14},{11,14},{10,14},{9,14}};
        for(int[] p:initial)worm.add(new Cell(p[0],p[1]));
        createObstacles();spawnApple();refresh();
    }
    private void addWall(int x,int y){
        Cell c=new Cell(x,y);if(!worm.contains(c)&&x>=0&&x<COLS&&y>=0&&y<ROWS)walls.add(c);
    }
    private void line(int x1,int y1,int x2,int y2){
        int steps=Math.max(Math.abs(x2-x1),Math.abs(y2-y1));
        for(int i=0;i<=steps;i++)addWall(x1+(x2-x1)*i/Math.max(1,steps),y1+(y2-y1)*i/Math.max(1,steps));
    }
    private void createObstacles(){
        if(level>=2){line(3,4,3,8);line(14,15,14,19);}
        if(level>=3){line(7,2,11,2);line(6,20,10,20);line(2,17,5,17);line(12,6,15,6);}
        if(level>=4){line(6,6,6,9);line(11,14,11,17);hazards.add(new Cell(9,5));hazardDirs.add(1);}
        if(level>=5){line(9,3,9,6);line(8,18,8,21);hazards.add(new Cell(4,20));hazardDirs.add(0);hazards.add(new Cell(15,10));hazardDirs.add(2);}
    }
    private boolean occupied(Cell c){return worm.contains(c)||walls.contains(c)||hazards.contains(c);}
    private void spawnApple(){
        ArrayList<Cell> free=new ArrayList<>();
        for(int y=0;y<ROWS;y++)for(int x=0;x<COLS;x++){
            Cell c=new Cell(x,y);if(!occupied(c))free.add(c);
        }
        apple=free.isEmpty()?null:free.get(random.nextInt(free.size()));
    }
    private void moveHazards(){
        for(int i=0;i<hazards.size();i++){
            Cell h=hazards.get(i);int d=hazardDirs.get(i);
            Cell n=new Cell(h.x+dx[d],h.y+dy[d]);
            if(n.x<1||n.x>=COLS-1||n.y<1||n.y>=ROWS-1||walls.contains(n)||hazards.contains(n)){
                d=(d+2)%4;hazardDirs.set(i,d);n=new Cell(h.x+dx[d],h.y+dy[d]);
            }
            if(n.x>=0&&n.x<COLS&&n.y>=0&&n.y<ROWS&&!walls.contains(n)&&!hazards.contains(n))hazards.set(i,n);
        }
    }
    private void step(){
        direction=nextDirection;tickCount++;
        if(level>=4)moveHazards();
        Cell head=worm.getFirst();Cell next=new Cell(head.x+dx[direction],head.y+dy[direction]);
        if(next.x<0||next.x>=COLS||next.y<0||next.y>=ROWS){
            newGame(1);status.setText("OUT OF BOUNDS!\nGAME RESET\n\nPRESS START");return;
        }
        if(walls.contains(next)||hazards.contains(next)||hazards.stream().anyMatch(worm::contains)){
            int current=level;newGame(current);status.setText("OBSTACLE HIT!\nRETRY LEVEL "+current+"\n\nPRESS START");return;
        }
        int crossing=worm.indexOf(next);
        if(crossing>=0){
            // Preserve the body from the old head up to (but excluding) the crossed cell.
            // All segments from the crossing point toward the tail are discarded.
            while(worm.size()>crossing)worm.removeLast();
        }
        worm.addFirst(next);
        boolean ate=next.equals(apple);
        if(ate){
            apples++;
            targetLength+=1; // 1 cell = 5% of the original 20-cell length.
        }
        while(worm.size()>targetLength)worm.removeLast();
        if(ate){
            if(apples>=GOAL){
                paused=true;transitioning=true;
                if(level==5){victory=true;transitioning=false;status.setText("YOU WIN!\nALL 5 LEVELS COMPLETE\n\nPRESS START TO REPLAY");}
                else{unlocked=Math.max(unlocked,level+1);prefs.edit().putInt("unlocked",unlocked).apply();
                    status.setText("LEVEL "+level+" COMPLETE!\n25 APPLES COLLECTED\n\nPRESS START FOR LEVEL "+(level+1));}
            }else spawnApple();
        }
        refresh();
    }
    private final Runnable loop=new Runnable(){@Override public void run(){
        if(!paused)step();
        handler.postDelayed(this,Math.max(95,220-(level-1)*25));
    }};
    private void refresh(){
        if(hud!=null)hud.setText("LEVEL "+level+" / 5     APPLES "+apples+" / 25");
        if(status!=null){
            if(!paused)status.setVisibility(View.GONE);
            else{status.setVisibility(View.VISIBLE);
                if(!transitioning&&!victory&&status.getText().toString().indexOf("HIT!")<0&&status.getText().toString().indexOf("BOUNDS!")<0)
                    status.setText("PAUSED\n\nPRESS START OR A DIRECTION");
            }
        }
        if(gameView!=null)gameView.invalidate();
    }
    @Override protected void onPause(){super.onPause();paused=true;if(status!=null)status.setText("PAUSED\n\nPRESS START");refresh();}
    @Override protected void onDestroy(){handler.removeCallbacks(loop);super.onDestroy();}

    private class GameView extends View {
        private final Paint p=new Paint();
        private float left,top,cell;
        GameView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            float size=Math.min(getWidth()/(float)COLS,getHeight()/(float)ROWS);
            cell=size;left=(getWidth()-COLS*cell)/2;top=(getHeight()-ROWS*cell)/2;
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF11201D);canvas.drawColor(0xFF11201D);
            rect(canvas,left-3,top-3,left+COLS*cell+3,top+ROWS*cell+3,0xFFE3C879);
            rect(canvas,left,top,left+COLS*cell,top+ROWS*cell,0xFF263E33);
            for(int y=0;y<ROWS;y++)for(int x=0;x<COLS;x++){
                if((x+y)%2==0)tile(canvas,x,y,0xFF2B4738,0.0f);
            }
            for(Cell w:walls){tile(canvas,w.x,w.y,0xFF7E827C,.07f);inner(canvas,w.x,w.y,0xFFAAB0A0,.20f);}
            for(Cell h:hazards){tile(canvas,h.x,h.y,0xFFD36A4B,.08f);inner(canvas,h.x,h.y,0xFFFFC36D,.27f);}
            if(apple!=null){tile(canvas,apple.x,apple.y,0xFF9D272F,.12f);
                inner(canvas,apple.x,apple.y,0xFFF65B49,.25f);
                rect(canvas,left+(apple.x+.45f)*cell,top+(apple.y+.02f)*cell,left+(apple.x+.65f)*cell,top+(apple.y+.25f)*cell,0xFF90C65B);
            }
            for(int i=worm.size()-1;i>=0;i--){Cell c=worm.get(i);
                tile(canvas,c.x,c.y,i==0?0xFFE8E17D:0xFF8AC46C,.045f);
                if(i==0){
                    float ex=c.x+.50f+dx[direction]*.20f,ey=c.y+.50f+dy[direction]*.20f;
                    rect(canvas,left+(ex-.13f)*cell,top+(ey-.13f)*cell,left+(ex+.13f)*cell,top+(ey+.13f)*cell,0xFF20362D);
                }else inner(canvas,c.x,c.y,0xFFB5D97A,.29f);
            }
        }
        private void tile(Canvas c,int x,int y,int color,float margin){
            rect(c,left+(x+margin)*cell,top+(y+margin)*cell,left+(x+1-margin)*cell,top+(y+1-margin)*cell,color);
        }
        private void inner(Canvas c,int x,int y,int color,float margin){
            rect(c,left+(x+margin)*cell,top+(y+margin)*cell,left+(x+1-margin)*cell,top+(y+1-margin)*cell,color);
        }
        private void rect(Canvas c,float a,float b,float d,float e,int color){p.setColor(color);c.drawRect(a,b,d,e,p);}
        private float downX,downY;
        @Override public boolean onTouchEvent(MotionEvent event){
            if(event.getAction()==MotionEvent.ACTION_DOWN){downX=event.getX();downY=event.getY();return true;}
            if(event.getAction()==MotionEvent.ACTION_UP){
                float x=event.getX()-downX,y=event.getY()-downY;
                if(Math.max(Math.abs(x),Math.abs(y))>dp(24))setDirection(Math.abs(x)>Math.abs(y)?(x>0?1:3):(y>0?2:0));
                else toggle();return true;
            }
            return true;
        }
    }
}
